
def getParam():
    c=20
    b=float(input("Enter Span Length:"))
    Q=float(input("Enter Free Stream Velocity:"))
    AoA=float(input("Enter Angle of Attack:"))
    return c,b,Q,AoA